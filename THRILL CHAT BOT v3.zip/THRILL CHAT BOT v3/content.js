// ============================================================
// THRILL Chat Farmer - v17 (Premium)
// 10-min context-aware Turkish replies | Live countdown | Premium UI
// ============================================================
console.log('[TCF] Thrill Chat Farmer v17 loading...');

// ===================== CONFIG =====================
const CONFIG = {
    intervalMs: 10 * 60 * 1000,                 // one message every 10 minutes
    firstDelayMs: 20000 + Math.floor(Math.random() * 25000), // first msg 20-45s after start
    jitterMs: 50000,                            // up to +50s random jitter (feels natural)
    contextCount: 20,                           // how many recent messages to read
    mentionChance: 0.3,                        // low chance to address a user by name
    minGap: 4000,                               // hard min gap between sends
    model: 'llama-3.3-70b-versatile'
};

// ===================== STATE =====================
let isRunning = false;
let nextSendAt = 0;
let lastSendTime = 0;
let isSending = false;
let totalSent = 0;
let replyCount = 0;
let aiCalls = 0, aiOk = 0, aiErr = 0;
let startTime = Date.now();
let tickTimer = null;
let AUTH = { authorized: false, username: null, reason: 'init', override: null };
let authPollTimer = null, authPollCount = 0;
let lastReplyPreview = '—';
let recentBotMessages = [];

// ===================== LOGGING =====================
function log(message, type = 'info') {
    const ts = new Date().toLocaleTimeString();
    console.log(`[TCF][${ts}] ${message}`);
    const logEl = document.getElementById('tcf-log');
    if (logEl) {
        const colors = { info: '#8b97ad', success: '#34d399', error: '#f87171', warning: '#fbbf24', ai: '#a78bfa', chat: '#60a5fa', debug: '#5b6678' };
        const entry = document.createElement('div');
        entry.className = 'tcf-log-line';
        entry.style.color = colors[type] || '#8b97ad';
        entry.innerHTML = `<span style="color:#4a5568">${ts}</span>  ${message}`;
        logEl.appendChild(entry);
        while (logEl.children.length > 60) logEl.removeChild(logEl.firstChild);
        logEl.scrollTop = logEl.scrollHeight;
    }
}

// ===================== DOM: CHAT INPUT =====================
function findChatInput() {
    const selectors = [
        'textarea[placeholder*="Message"]', 'textarea[placeholder*="message"]',
        'textarea[placeholder*="mesaj"]', 'textarea[placeholder*="yaz"]',
        'textarea', 'input[type="text"][placeholder*="message"]',
        'input[type="text"]', '[contenteditable="true"]', 'div[role="textbox"]'
    ];
    for (const selector of selectors) {
        try {
            const els = document.querySelectorAll(selector);
            for (const el of els) {
                if (el && el.offsetParent !== null) {
                    const ph = el.getAttribute('placeholder') || '';
                    if (ph.includes('Message') || ph.includes('message') || ph.includes('mesaj') ||
                        ph.includes('yaz') || el.closest('[class*="chat"]') || el.closest('[class*="Chat"]')) {
                        return el;
                    }
                }
            }
        } catch (e) {}
    }
    const tas = document.querySelectorAll('textarea');
    for (const el of tas) if (el.offsetParent !== null) return el;
    return null;
}

function findSendButton() {
    const input = findChatInput();
    if (!input) return null;
    let parent = input.parentElement;
    for (let i = 0; i < 10 && parent; i++) {
        const buttons = parent.querySelectorAll('button');
        for (const btn of buttons) {
            if (btn.offsetParent === null) continue;
            const html = btn.innerHTML || '';
            if (html.includes('fill-current') || html.includes('paper-plane') || html.includes('send')) return btn;
            const aria = btn.getAttribute('aria-label') || '';
            const title = btn.getAttribute('title') || '';
            const text = (btn.textContent || '').toLowerCase();
            const cls = btn.className || '';
            if (/send|gönder|gonder/i.test(aria + ' ' + title + ' ' + text + ' ' + cls)) return btn;
        }
        parent = parent.parentElement;
    }
    const all = document.querySelectorAll('button');
    for (const btn of all) {
        if (btn.offsetParent === null) continue;
        const html = btn.innerHTML || '';
        if (html.includes('fill-current') || html.includes('paper-plane') || html.includes('send')) return btn;
    }
    if (input) {
        const r1 = input.getBoundingClientRect();
        for (const btn of all) {
            if (btn.offsetParent === null) continue;
            const r2 = btn.getBoundingClientRect();
            if (r2.left > r1.left && Math.abs(r2.top - r1.top) < 50) {
                const text = (btn.textContent || '').toLowerCase();
                if (!text.includes('/') && !text.includes('command')) return btn;
            }
        }
    }
    return null;
}

function findChatContainer() {
    const exact = document.querySelector('.flex.min-h-0.grow');
    if (exact && exact.offsetParent !== null) return exact;
    const selectors = ['[class*="chat"]', '[class*="Chat"]', '[class*="message"]', '[class*="Message"]', '.chat-container', '#chat-container', 'main', 'section'];
    for (const selector of selectors) {
        try {
            const el = document.querySelector(selector);
            if (el && el.offsetParent !== null && el.querySelectorAll('p, div[class*="msg"], div[class*="message"]').length > 0) return el;
        } catch (e) {}
    }
    return document.querySelector('main') || null;
}

// ===================== READ CHAT =====================
function getMessageEls() {
    const container = findChatContainer();
    if (!container) return [];
    const selectors = ['.message-item', '.chat-message', '.msg', '[class*="message"]', '[class*="Message"]', '[class*="msg"]', 'p', 'div[class*="row"]'];
    for (const selector of selectors) {
        try {
            const items = container.querySelectorAll(selector);
            if (items.length > 0) return Array.from(items);
        } catch (e) {}
    }
    return Array.from(container.querySelectorAll('p'));
}

function extractSenderFrom(el) {
    try {
        let node = el;
        for (let i = 0; i < 4 && node; i++) {
            const cand = node.querySelector && node.querySelector('[class*="name"],[class*="Name"],[class*="user"],[class*="User"],[class*="author"],[class*="Author"]');
            if (cand) {
                const nm = (cand.textContent || '').replace(/\s+/g, ' ').trim();
                if (nm && nm.length >= 2 && nm.length <= 24 && !/\s{2,}/.test(nm)) return nm.split(' ')[0];
            }
            node = node.parentElement;
        }
    } catch (e) {}
    return null;
}

function getRecentMessages(n) {
    const els = getMessageEls();
    const out = [];
    let prev = '';
    for (const el of els) {
        let t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (t.length < 2) continue;
        if (t === prev) continue;
        prev = t;
        const sender = extractSenderFrom(el);
        if (sender && t.toLowerCase().indexOf(sender.toLowerCase()) === 0) {
            const stripped = t.slice(sender.length).replace(/^[:\-\s]+/, '').trim();
            if (stripped.length >= 2) t = stripped;
        }
        out.push(sender ? (sender + ': ' + t) : t);
    }
    return out.slice(-n);
}

function getLatestSender() {
    try {
        const els = getMessageEls();
        if (!els.length) return null;
        let node = els[els.length - 1];
        for (let i = 0; i < 5 && node; i++) {
            const cand = node.querySelector('[class*="name"],[class*="Name"],[class*="user"],[class*="User"],[class*="author"]');
            if (cand) {
                const name = (cand.textContent || '').replace(/\s+/g, ' ').trim();
                if (name && name.length >= 2 && name.length <= 24 && !/\s{2,}/.test(name)) return name.split(' ')[0];
            }
            node = node.parentElement;
        }
    } catch (e) {}
    return null;
}

// ===================== SEND =====================
async function sendMessage(message) {
    if (isSending) { log('Already sending, skipped', 'warning'); return false; }
    const input = findChatInput();
    const sendBtn = findSendButton();
    if (!input) { log('Chat input not found', 'error'); return false; }
    if (Date.now() - lastSendTime < CONFIG.minGap) { log('Too soon since last send', 'warning'); return false; }

    isSending = true;
    log(`Sending: \"${message}\"`, 'ai');
    try {
        if (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA') {
            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value') ||
                           Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
            input.focus();
            try { setter && setter.set ? setter.set.call(input, message) : (input.value = message); }
            catch (e) { input.value = message; }
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
            input.focus();
            input.textContent = message;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }
        await new Promise(r => setTimeout(r, 320));
        if (sendBtn) {
            sendBtn.click();
            sendBtn.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        }
        input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
        input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));

        lastSendTime = Date.now();
        totalSent++;
        lastReplyPreview = message;
        log(`Sent ✓ (total ${totalSent})`, 'success');
        updateUI();
        return true;
    } catch (e) {
        log('Send error: ' + e.message, 'error');
        return false;
    } finally {
        isSending = false;
    }
}

// ===================== AI REPLY =====================
function stripEmoji(s) {
    try {
        return String(s).replace(/[\p{Extended_Pictographic}\u{1F1E6}-\u{1F1FF}\uFE0F\u200D]/gu, '').replace(/\s{2,}/g, ' ').trim();
    } catch (e) {
        return String(s).replace(/\s{2,}/g, ' ').trim();
    }
}

function fallbackReply() {
    const pool = [
        'bu el nasıl gitti sizce', 'kasa bugün biraz cömert gibi', 'taktik olarak ne öneririsiniz',
        'ben şimdilik küçük oynuyorum', 'son birkaç eldir sessizlik var', 'biri büyük vurdu mu az önce',
        'bakalım bu sefer dönecek mi', 'sabırlı olan kazanıyor galiba', 'bonus geleni oldu mu bugün',
        'temkinli ilerliyorum bu ara', 'şans bugün kimden yana acaba', 'bu masada gidişat nasıl',
        'moralinizi bozmayın daha var', 'strateji değiştirme vakti mi ne', 'az önce güzel bir el kaçtı',
        'siz ne üstüne oynuyorsunuz', 'bu round biraz gergin geçti'
    ];
    const avail = pool.filter(p => recentBotMessages.indexOf(stripEmoji(p)) === -1);
    const src = avail.length ? avail : pool;
    return stripPunctuation(stripEmoji(src[Math.floor(Math.random() * src.length)]));
}

function rememberBotMessage(text) {
    recentBotMessages.push(stripEmoji(text));
    while (recentBotMessages.length > 12) recentBotMessages.shift();
}

function normalizeForCompare(s) {
    return stripEmoji(String(s)).toLowerCase().replace(/[^a-z0-9çğıöşü ]/gi, '').replace(/\s+/g, ' ').trim();
}

function tooSimilarToRecent(text) {
    const a = normalizeForCompare(text);
    if (!a) return false;
    for (const prev of recentBotMessages) {
        const b = normalizeForCompare(prev);
        if (!b) continue;
        if (a === b) return true;
        const aOpen = a.split(' ').slice(0, 3).join(' ');
        const bOpen = b.split(' ').slice(0, 3).join(' ');
        if (aOpen.length > 4 && aOpen === bOpen) return true;
        const aTokens = a.split(' ').filter(w => w.length > 3);
        const bSet = new Set(b.split(' ').filter(w => w.length > 3));
        if (aTokens.length && bSet.size) {
            let common = 0;
            for (const w of aTokens) if (bSet.has(w)) common++;
            if (common / Math.min(aTokens.length, bSet.size) >= 0.7) return true;
        }
    }
    return false;
}

function askGroq(messages, temperature) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
            type: 'groqChat',
            messages: messages,
            model: CONFIG.model,
            temperature: temperature
        }, (resp) => chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(resp));
    });
}

function stripPunctuation(s) {
    return String(s)
        .replace(/[.,?]/g, '')
        .replace(/[\u0022\u0027\u201c\u201d\u2018\u2019\u00ab\u00bb\u0060]/g, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
}

function cleanReply(raw) {
    let reply = (raw || '').trim();
    reply = stripEmoji(reply);
    reply = reply.replace(/^@?[A-Za-z0-9_]{2,24}\s*:\s*/, '').trim();
    reply = stripPunctuation(reply);
    if (reply.length > 180) reply = reply.substring(0, 180).trim();
    return reply;
}

async function generateContextualReply() {
    aiCalls++;
    const recent = getRecentMessages(CONFIG.contextCount);
    if (!recent.length) {
        log('No chat context found — skipping this cycle (AI only, no fallback)', 'warning');
        aiErr++;
        return '';
    }

    const transcript = recent.map(m => '- ' + m).join('\n');
    const lastMsg = recent[recent.length - 1];
    let mentionName = null;
    if (Math.random() < CONFIG.mentionChance) mentionName = getLatestSender();

    const avoid = recentBotMessages.slice(-8);
    const avoidBlock = avoid.length
        ? '\n\nDaha önce SEN şu mesajları yazdın. Bunları TEKRARLAMA; farklı kelimeler ve farklı bir açılış kullan:\n' + avoid.map(m => '- ' + m).join('\n')
        : '';

    const systemPrompt = [
        'Sen Thrill.com canlı oyun/sohbet odasında gerçek bir Türk oyuncusun. Türkçe yazıyorsun.',
        'GÖREV: Sohbetin son mesajlarını DİKKATLE OKU ve EN SON yazılan mesaja gerçekten cevap ver.',
        'Çoğunlukla CEVAP, görüş veya yorum ver; sürekli soru sorma. Biri soru sorduysa net bir cevap ver, bir şey anlattıysa ona katıl veya tepki ver.',
        'Soru sormak yerine kendi düşünceni veya cevabını söyle; en fazla çok nadiren soru sor.',
        'ASLA rastgele "günaydın", "iyi sabahlar", "nasılsınız", "herkese selam" gibi klişe selamlaşma yazma. Sadece biri SANA selam verdiyse karşılık ver.',
        'Her mesaj BENZERSİZ olmalı: aynı kalıbı, aynı açılışı, aynı cümleyi tekrar etme.',
        'Kurallar:',
        '- KESİNLİKLE emoji veya simge kullanma; yalnızca düz Türkçe metin.',
        '- HİÇBİR noktalama işareti kullanma: nokta virgül ve soru işareti tamamen yasak ve hiç tırnak kullanma; bunlarsız yaz.',
        '- 4-16 kelime; kısa, doğal, samimi, günlük konuşma dili. Tek cümle yeterli.',
        '- Son mesajın İÇERİĞİNE somut şekilde bağlan; havada genel laf etme.',
        '- Abartılı kazanç iddiası yok, kimseyi para yatırmaya teşvik etme, link paylaşma.',
        '- Tırnak işareti, etiket listesi veya açıklama yazma; sadece mesajın kendisi.',
        mentionName
            ? '- Mesaja "@' + mentionName + '" diye başla ve doğrudan onun yazdığına cevap ver.'
            : '- Son yazan kişiye doğal, doğrudan bir cevap ver.'
    ].join('\n');

    const userPrompt = 'Sohbetin son mesajları (en alttaki EN YENİ olan):\n' + transcript +
        '\n\nCEVAP VERMEN GEREKEN MESAJ: "' + lastMsg + '"' + avoidBlock +
        '\n\nŞimdi bu son mesaja uygun, özgün, soru sormak yerine cevap veya görüş içeren TEK bir Türkçe mesaj yaz. Hiç noktalama (nokta virgül soru işareti) ve hiç tırnak kullanma:';

    const baseMessages = [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
    ];

    try {
        let response = await askGroq(baseMessages, 0.95);
        let reply = (response && response.success && response.content) ? cleanReply(response.content) : '';

        let attempt = 0;
        while ((!reply || reply.length < 2 || tooSimilarToRecent(reply)) && attempt < 2) {
            attempt++;
            const retryMessages = baseMessages.concat([
                { role: 'user', content: 'Bu cevap fazla genel veya tekrar oldu. Tamamen farklı kelimelerle, son mesaja daha spesifik ve özgün, yeni bir cevap yaz.' }
            ]);
            const rr = await askGroq(retryMessages, 1.1 + attempt * 0.15);
            const rep = (rr && rr.success && rr.content) ? cleanReply(rr.content) : '';
            if (rep && rep.length >= 2 && !tooSimilarToRecent(rep)) { reply = rep; break; }
        }

        if (!reply || reply.length < 2) {
            aiErr++;
            log('AI returned nothing usable — skipping this cycle (no fallback)', 'warning');
            return '';
        }
        if (mentionName && reply.toLowerCase().indexOf('@') !== 0) reply = '@' + mentionName + ' ' + reply;
        aiOk++;
        rememberBotMessage(reply);
        log('AI reply ready: "' + reply + '"', 'success');
        return reply;
    } catch (e) {
        log('AI exception: ' + e.message + ' — skipping this cycle (no fallback)', 'error');
        aiErr++;
        return '';
    }
}

// ===================== CYCLE + SCHEDULER =====================
async function runCycle() {
    if (!isRunning) return;
    log('Reading chat & composing reply...', 'chat');
    const reply = await generateContextualReply();
    if (reply && reply.trim().length > 1) {
        const ok = await sendMessage(reply);
        if (ok) replyCount++;
    }
    updateUI();
}

function scheduleNext(delay) {
    nextSendAt = Date.now() + delay;
}

function tick() {
    updateTimerUI();
    if (isRunning && nextSendAt && Date.now() >= nextSendAt && !isSending) {
        // advance the next slot by EXACTLY the chosen interval (drift-free, no jitter)
        const target = nextSendAt + CONFIG.intervalMs;
        nextSendAt = target > Date.now() ? target : Date.now() + CONFIG.intervalMs;
        runCycle();
    }
}

function startBot() {
    if (isRunning) { log('Already running', 'warning'); return; }
    if (!AUTH.authorized) { log('Locked - this account is not authorized.', 'error'); revalidateAuth(); return; }
    isRunning = true;
    startTime = Date.now();
    scheduleNext(CONFIG.firstDelayMs);
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = setInterval(tick, 250);
    log('Bot started — first message in ~' + Math.round(CONFIG.firstDelayMs / 1000) + 's, then every ' + Math.round(CONFIG.intervalMs / 60000) + ' min', 'success');
    updateUI();
}

function stopBot() {
    if (!isRunning) { log('Already stopped', 'warning'); return; }
    isRunning = false;
    if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
    nextSendAt = 0;
    log('Bot stopped', 'error');
    updateTimerUI();
    updateUI();
}

// ===================== UI =====================
function fmt(ms) {
    if (ms < 0) ms = 0;
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

function injectStyles() {
    if (document.getElementById('tcf-style')) return;
    const st = document.createElement('style');
    st.id = 'tcf-style';
    st.textContent = `
    @keyframes tcf-pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.45;transform:scale(.82)} }
    @keyframes tcf-fade { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }
    @keyframes tcf-shimmer { to{background-position:200% center} }
    @keyframes tcf-avatar-glow { 0%,100%{box-shadow:0 0 0 2px rgba(255,255,255,.06),0 4px 16px rgba(124,131,160,.35)} 50%{box-shadow:0 0 0 2px rgba(255,255,255,.1),0 4px 22px rgba(167,139,250,.5)} }
    .tcf-pill{font-size:9px;font-weight:800;letter-spacing:.3px;padding:3px 9px 3px 8px;border-radius:999px;display:inline-flex;align-items:center;gap:5px;transition:color .3s ease,background .3s ease;}
    .tcf-user-anim{font-size:16px;font-weight:800;letter-spacing:.3px;background:linear-gradient(90deg,#7dd3fc,#a78bfa,#34d399,#7dd3fc);background-size:200% auto;-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;animation:tcf-shimmer 3s linear infinite;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:175px;}
    #tcf-auth-avatar{width:36px;height:36px;flex:none;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:800;color:#0b0f1a;text-transform:uppercase;background:linear-gradient(135deg,#7dd3fc,#a78bfa);animation:tcf-avatar-glow 3.2s ease-in-out infinite;}
    #tcf-panel { animation: tcf-fade .25s ease; }
    #tcf-panel *{box-sizing:border-box;}
    #tcf-interval-slider{-webkit-appearance:none;appearance:none;width:100%;height:5px;border-radius:999px;background:rgba(255,255,255,.12);outline:none;cursor:pointer;}
    #tcf-interval-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:16px;height:16px;border-radius:50%;background:linear-gradient(135deg,#7c5cff,#38bdf8);box-shadow:0 2px 8px rgba(124,92,255,.6);cursor:pointer;}
    #tcf-interval-slider::-moz-range-thumb{width:16px;height:16px;border:none;border-radius:50%;background:linear-gradient(135deg,#7c5cff,#38bdf8);box-shadow:0 2px 8px rgba(124,92,255,.6);cursor:pointer;}
    .tcf-btn{transition:transform .12s ease,filter .12s ease,background .2s ease;}
    .tcf-btn:hover{filter:brightness(1.12);}
    .tcf-btn:active{transform:scale(.96);}
    .tcf-log-line{padding:2px 0;font-size:10px;line-height:1.5;border-bottom:1px solid rgba(255,255,255,.03);font-family:ui-monospace,Menlo,monospace;}
    #tcf-ring-fg{transition:stroke-dashoffset .4s linear;}
    #tcf-body::-webkit-scrollbar,#tcf-log::-webkit-scrollbar{width:6px;}
    #tcf-body::-webkit-scrollbar-thumb,#tcf-log::-webkit-scrollbar-thumb{background:#2a3550;border-radius:3px;}
    `;
    document.head.appendChild(st);
}

function createPanel() {
    injectStyles();
    const panel = document.createElement('div');
    panel.id = 'tcf-panel';
    panel.style.cssText = `position:fixed;top:90px;right:22px;width:340px;z-index:2147483647;
        background:linear-gradient(160deg,#11151f 0%,#0c0f17 100%);
        border:1px solid rgba(255,255,255,.07);border-radius:20px;color:#e6ebf5;
        font-family:-apple-system,BlinkMacSystemFont,'Inter','Segoe UI',Roboto,sans-serif;
        box-shadow:0 24px 70px -12px rgba(0,0,0,.85),0 0 0 1px rgba(255,255,255,.02) inset;
        overflow:hidden;user-select:none;display:flex;flex-direction:column;max-height:90vh;`;

    const R = 52, C = 2 * Math.PI * R;
    panel.innerHTML = `
      <div id="tcf-header" style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;cursor:grab;
          background:linear-gradient(135deg,rgba(124,92,255,.16),rgba(56,189,248,.06));border-bottom:1px solid rgba(255,255,255,.06);">
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="width:30px;height:30px;border-radius:9px;display:grid;place-items:center;
              background:linear-gradient(135deg,#7c5cff,#4f7eff);box-shadow:0 4px 14px rgba(124,92,255,.5);overflow:hidden;"><img src="https://i.ibb.co/CpbTZjP8/mvp.png" alt="logo" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
          <div>
            <div style="font-weight:700;font-size:13.5px;letter-spacing:.2px;">Surya Chat Farmer</div>
            <div style="font-size:9px;color:#7c87a0;letter-spacing:.4px;">PREMIUM · v3</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <div id="tcf-pill" style="display:flex;align-items:center;gap:6px;padding:4px 9px;border-radius:999px;font-size:10px;font-weight:600;
              background:rgba(248,113,113,.14);color:#f87171;">
            <span id="tcf-dot" style="width:7px;height:7px;border-radius:50%;background:#f87171;"></span><span id="tcf-pill-text">Idle</span>
          </div>
          <button id="tcf-min" class="tcf-btn" style="background:transparent;border:none;color:#7c87a0;font-size:17px;cursor:pointer;line-height:1;">−</button>
        </div>
      </div>

      <div id="tcf-body" style="padding:18px 16px 16px;overflow-y:auto;">
        <!-- Countdown hero -->
        <div style="display:flex;align-items:center;gap:16px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);
            border-radius:16px;padding:16px;margin-bottom:14px;">
          <div style="position:relative;width:120px;height:120px;flex-shrink:0;">
            <svg width="120" height="120" style="transform:rotate(-90deg);">
              <circle cx="60" cy="60" r="${R}" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="9"/>
              <circle id="tcf-ring-fg" cx="60" cy="60" r="${R}" fill="none" stroke="url(#tcf-grad)" stroke-width="9"
                  stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C}"/>
              <defs><linearGradient id="tcf-grad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#7c5cff"/><stop offset="1" stop-color="#38bdf8"/></linearGradient></defs>
            </svg>
            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;">
              <div id="tcf-countdown" style="font-size:24px;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:.5px;">--:--</div>
              <div style="font-size:8px;color:#7c87a0;text-transform:uppercase;letter-spacing:1px;margin-top:2px;">next msg</div>
            </div>
          </div>
          <div style="flex:1;display:flex;flex-direction:column;gap:9px;">
            <div><div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.8px;">Uptime</div>
              <div id="tcf-uptime" style="font-size:14px;font-weight:700;font-variant-numeric:tabular-nums;">00:00</div></div>
            <div><div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.8px;">Interval</div>
              <div id="tcf-interval-val" style="font-size:14px;font-weight:700;">10 min</div></div>
          </div>
        </div>

        <!-- Interval slider -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:12px 14px;margin-bottom:14px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.8px;">Message interval</div>
            <div id="tcf-interval-badge" style="font-size:12px;font-weight:800;color:#a78bfa;">10 min</div>
          </div>
          <input id="tcf-interval-slider" type="range" min="1" max="15" step="1" value="10" />
          <div style="display:flex;justify-content:space-between;font-size:8px;color:#5b6678;margin-top:5px;">
            <span>1 min</span><span>15 min</span>
          </div>
        </div>

        <!-- Stats -->
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px;">
          ${statCard('tcf-sent', 'Sent', '#60a5fa')}
          ${statCard('tcf-replies', 'Replies', '#34d399')}
          ${statCard('tcf-ai', 'AI %', '#a78bfa')}
        </div>

        <!-- Last message -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:10px 12px;margin-bottom:14px;">
          <div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px;">Last sent</div>
          <div id="tcf-last" style="font-size:11.5px;color:#c4cde0;line-height:1.4;word-break:break-word;">—</div>
        </div>

        <!-- Controls -->
        <button id="tcf-toggle" class="tcf-btn" style="width:100%;border:none;padding:12px;border-radius:12px;color:#fff;cursor:pointer;
            font-weight:700;font-size:13px;margin-bottom:8px;background:linear-gradient(135deg,#7c5cff,#4f7eff);
            box-shadow:0 6px 18px rgba(124,92,255,.4);">▶  Start</button>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
          <button id="tcf-test" class="tcf-btn" style="border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);padding:9px;border-radius:10px;color:#cdd6e8;cursor:pointer;font-size:11px;font-weight:600;">Send test now</button>
          <button id="tcf-clear" class="tcf-btn" style="border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);padding:9px;border-radius:10px;color:#cdd6e8;cursor:pointer;font-size:11px;font-weight:600;">Clear log</button>
        </div>

        <!-- Access / Auth -->
        <div id="tcf-auth-box" style="position:relative;overflow:hidden;background:linear-gradient(135deg,rgba(124,131,160,.06),rgba(255,255,255,.02));border:1px solid rgba(125,211,252,.3);border-radius:14px;padding:13px;margin-bottom:14px;transition:border-color .35s ease,box-shadow .35s ease;">
          <div id="tcf-auth-glow" style="position:absolute;top:-45%;right:-15%;width:150px;height:150px;border-radius:50%;background:radial-gradient(circle,rgba(125,211,252,.16),transparent 70%);pointer-events:none;transition:background .4s ease;"></div>
          <div style="position:relative;display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:1.2px;font-weight:700;">Access</div>
            <div id="tcf-auth-status" class="tcf-pill" style="color:#7dd3fc;background:rgba(125,211,252,.12);">checking…</div>
          </div>
          <div style="position:relative;display:flex;align-items:center;gap:11px;">
            <div id="tcf-auth-avatar">?</div>
            <div style="min-width:0;flex:1;">
              <div id="tcf-auth-user" style="color:#5b6678;font-size:16px;font-weight:800;">-</div>
              <div id="tcf-auth-expiry" style="font-size:9px;color:#6b7790;margin-top:3px;line-height:1.4;">verifying access…</div>
            </div>
          </div>
        </div>

        <!-- API Keys -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:11px 12px;margin-bottom:14px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.8px;">API keys</div>
            <div id="tcf-key-count" style="font-size:9px;color:#7c87a0;">-</div>
          </div>
          <textarea id="tcf-key-input" placeholder="Khudki keys" rows="2" style="width:100%;resize:vertical;background:#080b11;border:1px solid rgba(255,255,255,.08);border-radius:8px;color:#cdd6e8;font-size:10px;font-family:ui-monospace,monospace;padding:7px 8px;margin-bottom:7px;outline:none;"></textarea>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;">
            <button id="tcf-key-save" class="tcf-btn" style="border:none;background:linear-gradient(135deg,#7c5cff,#4f7eff);padding:8px;border-radius:8px;color:#fff;cursor:pointer;font-size:10.5px;font-weight:700;">Save keys</button>
            <button id="tcf-key-test" class="tcf-btn" style="border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);padding:8px;border-radius:8px;color:#cdd6e8;cursor:pointer;font-size:10.5px;font-weight:600;">Test keys</button>
          </div>
          <div id="tcf-key-results" style="margin-top:8px;display:flex;flex-direction:column;gap:3px;"></div>
        </div>

        <!-- Log -->
        <div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;">Live activity</div>
        <div id="tcf-log" style="background:#080b11;border:1px solid rgba(255,255,255,.05);border-radius:10px;padding:8px 10px;max-height:130px;overflow-y:auto;"></div>
      </div>`;

    document.body.appendChild(panel);
    wirePanel(panel, C);
    updateUI();
    updateTimerUI();
    log('Panel ready. Press Start when you are in a chat room.', 'info');
}

function statCard(id, label, color) {
    return `<div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:10px 6px;text-align:center;">
        <div id="${id}" style="font-size:19px;font-weight:800;color:${color};font-variant-numeric:tabular-nums;">0</div>
        <div style="font-size:8px;color:#6b7790;text-transform:uppercase;letter-spacing:.6px;margin-top:2px;">${label}</div></div>`;
}

function wirePanel(panel, C) {
    const header = document.getElementById('tcf-header');
    let drag = false, ox = 0, oy = 0;
    header.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) return;
        drag = true; const r = panel.getBoundingClientRect();
        ox = e.clientX - r.left; oy = e.clientY - r.top;
        header.style.cursor = 'grabbing'; panel.style.transition = 'none';
    });
    document.addEventListener('mousemove', (e) => {
        if (!drag) return;
        let x = Math.max(8, Math.min(window.innerWidth - panel.offsetWidth - 8, e.clientX - ox));
        let y = Math.max(8, Math.min(window.innerHeight - panel.offsetHeight - 8, e.clientY - oy));
        panel.style.left = x + 'px'; panel.style.top = y + 'px'; panel.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => { if (drag) { drag = false; header.style.cursor = 'grab'; } });

    document.getElementById('tcf-min').addEventListener('click', () => {
        const b = document.getElementById('tcf-body');
        b.style.display = b.style.display === 'none' ? 'block' : 'none';
    });
    document.getElementById('tcf-toggle').addEventListener('click', () => { isRunning ? stopBot() : startBot(); });
    const slider = document.getElementById('tcf-interval-slider');
    if (slider) {
        slider.value = String(Math.round(CONFIG.intervalMs / 60000));
        slider.addEventListener('input', () => {
            const mins = Math.max(1, Math.min(15, parseInt(slider.value, 10) || 10));
            CONFIG.intervalMs = mins * 60 * 1000;
            const label = mins + ' min';
            const badge = document.getElementById('tcf-interval-badge');
            const ival = document.getElementById('tcf-interval-val');
            if (badge) badge.textContent = label;
            if (ival) ival.textContent = label;
            if (isRunning) scheduleNext(CONFIG.intervalMs);
            log('Interval set to ' + label + ' (exact, every message)', 'info');
        });
    }
    document.getElementById('tcf-test').addEventListener('click', async () => { log('Manual test send', 'info'); await runCycle(); });
    document.getElementById('tcf-clear').addEventListener('click', () => { const l = document.getElementById('tcf-log'); if (l) l.innerHTML = ''; log('Log cleared', 'debug'); });

    const rt = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, res); } catch (e) { res(null); } });
    async function refreshKeyInfo() {
        const info = await rt({ type: 'getApiKeys' });
        const el = document.getElementById('tcf-key-count');
        if (el && info) el.textContent = info.count + ' loaded - ' + (info.usingUserKeys ? 'your keys' : 'bundled');
    }
    refreshKeyInfo();
    document.getElementById('tcf-key-save').addEventListener('click', async () => {
        const raw = document.getElementById('tcf-key-input').value || '';
        const keys = raw.split(/[\n, ]+/).map(s => s.trim()).filter(s => s.startsWith('gsk_'));
        if (!keys.length) { log('No valid gsk_ keys found in the box', 'warning'); return; }
        const r = await rt({ type: 'setApiKeys', keys });
        if (r && r.success) { log('Saved ' + r.count + ' key(s) to secure storage', 'success'); document.getElementById('tcf-key-input').value = ''; refreshKeyInfo(); }
        else { log('Failed to save keys', 'error'); }
    });
    document.getElementById('tcf-key-test').addEventListener('click', async () => {
        const box = document.getElementById('tcf-key-results');
        box.innerHTML = '<div style="font-size:10px;color:#7c87a0;">Testing...</div>';
        const raw = document.getElementById('tcf-key-input').value || '';
        const typed = raw.split(/[\n, ]+/).map(s => s.trim()).filter(s => s.startsWith('gsk_'));
        const r = await rt({ type: 'testApiKeys', keys: typed.length ? typed : undefined });
        if (!r || !r.success) { box.innerHTML = '<div style="font-size:10px;color:#f87171;">Test failed</div>'; return; }
        box.innerHTML = '';
        r.results.forEach(res => {
            const color = res.ok ? '#34d399' : (res.rateLimited ? '#fbbf24' : '#f87171');
            const label = res.ok ? 'valid (200)' : (res.rateLimited ? 'rate-limited' : (res.status === 0 ? 'no response' : 'invalid (' + res.status + ')'));
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;font-size:10px;font-family:ui-monospace,monospace;';
            row.innerHTML = '<span style="color:#8b97ad;">#' + res.slot + ' ' + res.masked + '</span><span style="color:' + color + ';font-weight:700;">' + label + '</span>';
            box.appendChild(row);
        });
    });
    panel._C = C;
}

function updateTimerUI() {
    const panel = document.getElementById('tcf-panel');
    const cd = document.getElementById('tcf-countdown');
    const up = document.getElementById('tcf-uptime');
    const ring = document.getElementById('tcf-ring-fg');
    if (!panel) return;
    const C = panel._C || (2 * Math.PI * 52);
    if (isRunning && nextSendAt) {
        const left = nextSendAt - Date.now();
        if (cd) cd.textContent = fmt(left);
        const frac = Math.max(0, Math.min(1, left / CONFIG.intervalMs));
        if (ring) ring.setAttribute('stroke-dashoffset', String(C * (1 - frac)));
    } else {
        if (cd) cd.textContent = '--:--';
        if (ring) ring.setAttribute('stroke-dashoffset', String(C));
    }
    if (up) up.textContent = isRunning ? fmt(Date.now() - startTime) : '00:00';
}

function updateUI() {
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set('tcf-sent', totalSent);
    set('tcf-replies', replyCount);
    set('tcf-ai', aiCalls > 0 ? Math.round((aiOk / aiCalls) * 100) : 0);
    set('tcf-last', lastReplyPreview);
    const pill = document.getElementById('tcf-pill');
    const dot = document.getElementById('tcf-dot');
    const pt = document.getElementById('tcf-pill-text');
    const tg = document.getElementById('tcf-toggle');
    if (pill && dot && pt) {
        if (isRunning) {
            pill.style.background = 'rgba(52,211,153,.14)'; pill.style.color = '#34d399';
            dot.style.background = '#34d399'; dot.style.animation = 'tcf-pulse 1.4s infinite';
            pt.textContent = 'Running';
        } else {
            pill.style.background = 'rgba(248,113,113,.14)'; pill.style.color = '#f87171';
            dot.style.background = '#f87171'; dot.style.animation = 'none';
            pt.textContent = 'Idle';
        }
    }
    if (tg) {
        tg.innerHTML = isRunning ? '⏹  Stop' : '▶  Start';
        tg.style.background = isRunning ? 'linear-gradient(135deg,#ef4444,#dc2626)' : 'linear-gradient(135deg,#7c5cff,#4f7eff)';
        tg.style.boxShadow = isRunning ? '0 6px 18px rgba(239,68,68,.4)' : '0 6px 18px rgba(124,92,255,.4)';
    }
}

// ===================== AUTH =====================
function rt2(msg) { return new Promise((resolve) => { try { chrome.runtime.sendMessage(msg, resolve); } catch (e) { resolve(null); } }); }

const STRONG_KEYS = ['username', 'userName', 'user_name', 'handle', 'nickname', 'screenName', 'screen_name'];
const WEAK_KEYS = ['displayName', 'display_name', 'login', 'name'];
const ALL_KEYS = STRONG_KEYS.concat(WEAK_KEYS);
const BAD_USER = ['thrill', 'thrill.com', 'guest', 'user', 'users', 'admin', 'anonymous', 'anon', 'unknown', 'null', 'undefined', 'player', 'name',
    'casino', 'slots', 'slot', 'sports', 'sport', 'sportsbook', 'live', 'livecasino', 'originals', 'original', 'games', 'game', 'home', 'lobby',
    'promotions', 'promotion', 'promo', 'rewards', 'reward', 'vip', 'affiliate', 'affiliates', 'blog', 'support', 'help', 'wallet', 'deposit',
    'withdraw', 'withdrawal', 'cashier', 'favorites', 'favourites', 'popular', 'trending', 'recent', 'new', 'search', 'menu', 'settings',
    'profile', 'account', 'login', 'logout', 'register', 'signup', 'signin', 'balance', 'bonus', 'bonuses', 'racing', 'poker', 'table', 'tables'];

function validUser(v) {
    if (typeof v !== 'string') return null;
    const t = v.trim();
    if (t.length < 2 || t.length > 32 || t.indexOf(' ') !== -1) return null;
    if (!/[a-zA-Z]/.test(t)) return null;
    if (/^[\d.,$€£₹%+\-]+$/.test(t)) return null;
    const low = t.toLowerCase();
    if (BAD_USER.indexOf(low) !== -1) return null;
    if (low.indexOf('thrill') !== -1) return null;
    return t;
}

function walkForUsername(obj, depth, keys) {
    if (!obj || depth > 8 || typeof obj !== 'object') return null;
    keys = keys || ALL_KEYS;
    for (const k of keys) {
        const got = validUser(obj[k]);
        if (got) return got;
    }
    for (const key in obj) {
        try { const v = obj[key]; if (v && typeof v === 'object') { const f = walkForUsername(v, depth + 1, keys); if (f) return f; } } catch (e) {}
    }
    return null;
}

function tryJwt(v, keys) {
    try {
        if (!v || typeof v !== 'string') return null;
        const parts = v.split('.');
        if (parts.length < 2 || parts.length > 3) return null;
        let b = parts[1].replace(/-/g, '+').replace(/_/g, '/');
        while (b.length % 4) b += '=';
        return walkForUsername(JSON.parse(atob(b)), 0, keys);
    } catch (e) { return null; }
}

function extractUsername(str, keys) {
    if (!str || typeof str !== 'string' || str.length > 300000) return null;
    try { const u = walkForUsername(JSON.parse(str), 0, keys); if (u) return u; } catch (e) {}
    return tryJwt(str, keys);
}

function scanStore(store, keys) {
    try {
        for (let i = 0; i < store.length; i++) {
            const u = extractUsername(store.getItem(store.key(i)), keys);
            if (u) return u;
        }
    } catch (e) {}
    return null;
}

function scanGlobals(keys) {
    const cands = ['__NUXT__', '__NEXT_DATA__', '__INITIAL_STATE__', '__APP_STATE__', '__REDUX_STATE__', '__APOLLO_STATE__', '__remixContext'];
    for (const g of cands) {
        try { const obj = window[g]; if (obj && typeof obj === 'object') { const u = walkForUsername(obj, 0, keys); if (u) return u; } } catch (e) {}
    }
    return null;
}

function scanCookies(keys) {
    try {
        const parts = (document.cookie || '').split(';');
        for (const p of parts) {
            const idx = p.indexOf('=');
            if (idx === -1) continue;
            let v = p.slice(idx + 1).trim();
            try { v = decodeURIComponent(v); } catch (e) {}
            let u = extractUsername(v, keys);
            if (u) return u;
            try { u = extractUsername(atob(v), keys); if (u) return u; } catch (e) {}
        }
    } catch (e) {}
    return null;
}

function scanDom() {
    const sels = ['[data-testid*="username" i]', '[class*="username" i]', '[class*="userName"]', '[class*="profile" i] [class*="name" i]', 'header [class*="name" i]'];
    for (const s of sels) {
        try { const el = document.querySelector(s); if (el) { const got = validUser((el.textContent || '').trim()); if (got) return got; } } catch (e) {}
    }
    return null;
}

function dumpStorage() {
    const d = { localStorage: {}, sessionStorage: {}, cookies: document.cookie, globals: [] };
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); d.localStorage[k] = (localStorage.getItem(k) || '').slice(0, 400); } } catch (e) {}
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); d.sessionStorage[k] = (sessionStorage.getItem(k) || '').slice(0, 400); } } catch (e) {}
    ['__NUXT__', '__NEXT_DATA__', '__INITIAL_STATE__', '__APP_STATE__', '__REDUX_STATE__', '__APOLLO_STATE__', '__remixContext'].forEach(g => { try { if (window[g]) d.globals.push(g); } catch (e) {} });
    console.log('[TCF] storage dump:', d);
    return d;
}

function detectPass(keys) {
    try {
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (!k) continue;
            const low = k.toLowerCase();
            if (low.indexOf('user') === -1 && low.indexOf('auth') === -1 && low.indexOf('session') === -1 && low.indexOf('profile') === -1 && low.indexOf('account') === -1 && low.indexOf('token') === -1) continue;
            const u = extractUsername(localStorage.getItem(k), keys);
            if (u) return u;
        }
    } catch (e) {}
    return scanStore(localStorage, keys) || scanStore(sessionStorage, keys) || scanGlobals(keys) || scanCookies(keys);
}

function scanThrillUser() {
    const tiers = [
        '[class*="typ-display-xsmall"][class*="text-foreground-primary"][class*="font-bold"][class*="uppercase"]',
        '[class*="typ-display-xsmall"][class*="text-foreground-primary"][class*="font-bold"]'
    ];
    for (const sel of tiers) {
        try {
            const els = document.querySelectorAll(sel);
            for (const el of els) {
                let direct = '';
                for (const n of el.childNodes) if (n.nodeType === 3) direct += n.textContent;
                const got = validUser(direct.trim()) || validUser((el.textContent || '').trim());
                if (got) return got;
            }
        } catch (e) {}
    }
    return null;
}

function detectUsername() {
    if (AUTH.override) return AUTH.override;
    return scanThrillUser() || detectPass(STRONG_KEYS) || detectPass(WEAK_KEYS) || scanDom();
}

function findUserCandidates() {
    const out = [];
    const push = (src, v) => { if (v) out.push({ source: src, value: v }); };
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); push('localStorage:' + k, extractUsername(localStorage.getItem(k), ALL_KEYS)); } } catch (e) {}
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); push('sessionStorage:' + k, extractUsername(sessionStorage.getItem(k), ALL_KEYS)); } } catch (e) {}
    push('cookies', scanCookies(ALL_KEYS));
    push('globals', scanGlobals(ALL_KEYS));
    push('thrill-dom', scanThrillUser());
    push('dom', scanDom());
    console.log('[TCF] Username candidates:', out);
    dumpStorage();
    log(out.length ? ('Found ' + out.length + ' candidate(s) - see console') : 'No candidates - run window.tcf.dump() in console', out.length ? 'success' : 'warning');
    return out;
}

async function revalidateAuth() {
    const username = detectUsername();
    AUTH.username = username;
    const aEl = document.getElementById('tcf-auth-user');
    const sEl = document.getElementById('tcf-auth-status');
    const avEl = document.getElementById('tcf-auth-avatar');
    if (aEl) { aEl.textContent = username || 'not detected'; aEl.className = username ? 'tcf-user-anim' : ''; aEl.style.color = username ? '' : '#5b6678'; }
    if (avEl) avEl.textContent = username ? username[0].toUpperCase() : '?';
    if (sEl) { sEl.innerHTML = '<span style="width:6px;height:6px;border-radius:50%;background:#7dd3fc;box-shadow:0 0 6px #7dd3fc;animation:tcf-pulse 1.6s ease-in-out infinite;"></span>Checking…'; sEl.style.color = '#7dd3fc'; sEl.style.background = 'rgba(125,211,252,.12)'; }
    const resp = await rt2({ type: 'checkAuth', username });
    AUTH.authorized = !!(resp && resp.authorized);
    AUTH.reason = (resp && resp.reason) || 'error';
    AUTH.expiresAt = (resp && resp.expires_at) || null;
    if (!AUTH.authorized && isRunning) stopBot();
    updateUI();
    updateAuthUI();
    return AUTH.authorized;
}

function startAuthAutoDetect() {
    if (authPollTimer) { clearInterval(authPollTimer); authPollTimer = null; }
    authPollCount = 0;
    revalidateAuth();
    authPollTimer = setInterval(async () => {
        authPollCount++;
        await revalidateAuth();
        if (AUTH.username || authPollCount >= 30) { clearInterval(authPollTimer); authPollTimer = null; }
    }, 2000);
}

function updateAuthUI() {
    const sEl = document.getElementById('tcf-auth-status');
    const exEl = document.getElementById('tcf-auth-expiry');
    const glow = document.getElementById('tcf-auth-glow');
    const setPill = (text, color, bg) => { if (!sEl) return; sEl.innerHTML = '<span style="width:6px;height:6px;border-radius:50%;background:' + color + ';box-shadow:0 0 6px ' + color + ';animation:tcf-pulse 1.6s ease-in-out infinite;"></span>' + text; sEl.style.color = color; sEl.style.background = bg; };
    if (AUTH.authorized) {
        setPill('Authorized', '#34d399', 'rgba(52,211,153,.14)');
        if (exEl) {
            if (AUTH.expiresAt) {
                const d = new Date(AUTH.expiresAt);
                const hours = Math.ceil((d.getTime() - Date.now()) / 3600000);
                const tag = hours <= 24 ? '#f87171' : '#34d399';
                const left = hours > 1 ? (hours + ' hours left') : (hours === 1 ? '1 hour left' : 'expires soon');
                exEl.innerHTML = 'Expires ' + d.toLocaleString(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' <span style="color:' + tag + ';font-weight:800;">· ' + left + '</span>';
            } else {
                exEl.innerHTML = '<span style="color:#34d399;font-weight:800;">Lifetime access</span> · never expires';
            }
            exEl.style.color = '#8b97ad';
        }
        if (glow) glow.style.background = 'radial-gradient(circle,rgba(52,211,153,.20),transparent 70%)';
    } else {
        const warn = AUTH.reason === 'init' || AUTH.reason === 'no_username';
        const map = { not_configured: 'Config missing', no_username: 'Detecting…', no_match: 'Not on allowlist', expired: 'Access expired', disabled: 'Access disabled', error: 'Check failed', init: 'Checking…' };
        const color = warn ? '#7dd3fc' : '#f87171';
        setPill(map[AUTH.reason] || 'Locked', color, warn ? 'rgba(125,211,252,.12)' : 'rgba(248,113,113,.12)');
        if (exEl) {
            const emap = { not_configured: 'Backend not configured.', no_username: 'Profile open kro fir detect hoga', no_match: 'This username is not authorized for access.', expired: 'Your access period has ended.', disabled: 'Your access has been disabled.', error: 'Could not verify access right now.', init: 'Verifying access…' };
            exEl.textContent = emap[AUTH.reason] || 'Access is locked.';
            exEl.style.color = '#6b7790';
        }
        if (glow) glow.style.background = warn ? 'radial-gradient(circle,rgba(125,211,252,.16),transparent 70%)' : 'radial-gradient(circle,rgba(248,113,113,.16),transparent 70%)';
    }
    const box = document.getElementById('tcf-auth-box');
    if (box) { box.style.borderColor = AUTH.authorized ? 'rgba(52,211,153,.4)' : ((AUTH.reason === 'init' || AUTH.reason === 'no_username') ? 'rgba(125,211,252,.3)' : 'rgba(248,113,113,.35)'); box.style.boxShadow = AUTH.authorized ? '0 0 22px rgba(52,211,153,.12)' : 'none'; }
    const tg = document.getElementById('tcf-toggle');
    if (tg && !AUTH.authorized && !isRunning) {
        tg.innerHTML = '🔒  Locked';
        tg.style.opacity = '0.5';
        tg.style.cursor = 'not-allowed';
        tg.style.background = 'linear-gradient(135deg,#3a4256,#2a3142)';
        tg.style.boxShadow = 'none';
    } else if (tg && AUTH.authorized) {
        tg.style.opacity = '1';
        tg.style.cursor = 'pointer';
    }
}

// ===================== GLOBAL API =====================
window.tcf = {
    start: startBot, stop: stopBot, toggle: () => isRunning ? stopBot() : startBot(),
    send: sendMessage, cycle: runCycle,
    stats: () => ({ totalSent, replyCount, aiCalls, aiOk, aiErr, isRunning, nextInMs: nextSendAt ? nextSendAt - Date.now() : 0 }),
    findUser: findUserCandidates, detectUser: detectUsername, recheck: startAuthAutoDetect, dump: dumpStorage, auth: () => AUTH,
    config: CONFIG
};

// ===================== KEYBOARD =====================
document.addEventListener('keydown', (e) => {
    if (e.key === 'F1' || (e.ctrlKey && e.key.toLowerCase() === 'b')) {
        e.preventDefault();
        const p = document.getElementById('tcf-panel');
        if (p) p.style.display = p.style.display === 'none' ? 'flex' : 'none';
        else createPanel();
    }
});

// ===================== INIT =====================
function init() {
    const THRILL_HOSTS = ['thrill.com', 'thrill.ac', 'thrill.pet', 'thrill.jp', 'thrill.krd', 'thrill.bj'];
    if (!THRILL_HOSTS.some(h => window.location.hostname.includes(h))) return;
    if (document.getElementById('tcf-panel')) return;
    createPanel();
    startAuthAutoDetect();
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !AUTH.authorized) startAuthAutoDetect(); });
    let attempts = 0;
    const iv = setInterval(() => {
        attempts++;
        const ready = findChatContainer() && findChatInput();
        if (ready) { clearInterval(iv); log('Chat detected — ready to farm.', 'success'); }
        else if (attempts >= 15) { clearInterval(iv); log('Open a chat room, then press Start.', 'warning'); }
    }, 2000);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(init, 600));
else setTimeout(init, 600);
window.addEventListener('load', () => setTimeout(init, 1200));

console.log('[TCF] v17 loaded — F1 / Ctrl+B toggles the panel.');
